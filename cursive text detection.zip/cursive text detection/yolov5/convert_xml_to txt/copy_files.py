import shutil
import os
# for i in os.listdir('/media/zirsha/New Volume/Bottledetection/dataset/validation/images'):
#     shutil.copy('/media/zirsha/New Volume/Bottledetection/dataset/validation/images/'+i,'/media/zirsha/New Volume/darknet-master/custom_data/images/'+i)

for i in os.listdir('/media/zirsha/New Volume/PPE_detection/dataset/train/annotations'):
    # print(i)
    a=i.split('.')
    os.walk('/media/zirsha/New Volume/PPE_detection/dataset/train/images')
    # print(a[0])
    # if(a[1]=='txt'):
    # try:
    #     shutil.copy('/media/zirsha/New Volume/PPE_detection/dataset/train/images/'+a[0]+'.txt','/media/zirsha/New Volume/convert2Yolo-master/training/data/images/train/'+a[0]+'.txt')
    # except:
    #     print(a[0]+'.jpg')