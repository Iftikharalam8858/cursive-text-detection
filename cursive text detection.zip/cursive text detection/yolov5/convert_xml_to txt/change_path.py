with open('/media/zirsha/New Volume/convert2Yolo-master/test.txt','r') as f:
    list=(f.readlines())
new=[]
# print(list)
with open('new_test.txt','w') as f:
    for i in list:
        # print(i)
        path=i.split('/')
        # print(path[-1])
        f.write('/content/gdrive/My Drive/yolo/darknet/bottle/'+path[-1])

# print(new)
